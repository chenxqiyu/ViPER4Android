#!/system/bin/sh
MODDIR=${0%/*}

V4A_LOG=/data/adb/viper_install.log
log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] [post-fs-data] $1" >>$V4A_LOG; }

log "---> post-fs-data start <---"
log "SELinux before: $(getenforce 2>/dev/null || echo unknown)"

setenforce 0 2>/dev/null || echo 0 >/sys/fs/selinux/enforce 2>/dev/null
log "SELinux after: $(getenforce 2>/dev/null || echo unknown)"

V4A_SEPOLICY="type viper_control_service service_manager_type
allow hal_audio_default viper_control_service service_manager add
allow untrusted_app viper_control_service service_manager find
allow hal_audio_default default_android_service service_manager add
allow untrusted_app default_android_service service_manager find
allow hal_audio_default servicemanager binder { call transfer }
allow untrusted_app hal_audio_default binder { call transfer }"

POLICY_TOOL=""
POLICY_TYPE=""
if command -v ksud >/dev/null 2>&1; then
  POLICY_TOOL="ksud"
  POLICY_TYPE="ksu"
elif [ -x /data/adb/ksu/bin/ksud ]; then
  POLICY_TOOL="/data/adb/ksu/bin/ksud"
  POLICY_TYPE="ksu"
elif command -v magiskpolicy >/dev/null 2>&1; then
  POLICY_TOOL="magiskpolicy"
  POLICY_TYPE="magisk"
elif [ -x /data/adb/magisk/magiskpolicy ]; then
  POLICY_TOOL="/data/adb/magisk/magiskpolicy"
  POLICY_TYPE="magisk"
elif [ -x /data/adb/ap/bin/apd ]; then
  POLICY_TOOL="/data/adb/ap/bin/apd"
  POLICY_TYPE="apatch"
fi

log "Applying SELinux policy rules (tool: ${POLICY_TOOL:-not found}, type: ${POLICY_TYPE:-unknown})..."
if [ -n "$POLICY_TOOL" ]; then
  RULE_FILE="$MODDIR/v4a_sepolicy.tmp"
  echo "$V4A_SEPOLICY" >"$RULE_FILE"
  case "$POLICY_TYPE" in
  ksu)
    POLICY_ERR=$($POLICY_TOOL sepolicy apply "$RULE_FILE" 2>&1)
    POLICY_RC=$?
    ;;
  apatch)
    POLICY_ERR=$($POLICY_TOOL sepolicy --live --apply "$RULE_FILE" 2>&1)
    POLICY_RC=$?
    ;;
  magisk)
    POLICY_ERR=$($POLICY_TOOL --live --apply "$RULE_FILE" 2>&1)
    POLICY_RC=$?
    ;;
  esac
  rm -f "$RULE_FILE"
  if [ "$POLICY_RC" -ne 0 ]; then
    log "Policy inject failed (rc=$POLICY_RC): $POLICY_ERR"
  else
    log "Policy inject applied (rc=0)"
  fi
else
  log "WARNING: No policy tool found. Relying on sepolicy.rule static rules."
fi

SELF_MOUNT=false
[ -f "$MODDIR/skip_mount" ] && SELF_MOUNT=true

ns_mount() {
  if nsenter -t 1 -m -- mount -o bind "$1" "$2" 2>/dev/null; then
    return 0
  fi
  mount -o bind "$1" "$2"
}

# cp -a keeps symlinks (e.g. libmisoundfx.so -> /vendor/lib64/...); they must be
# labeled too or the HAL cannot dlopen them once SELinux is enforcing again.
label_tree() {
  local dir="$1"
  local ctx="$2"
  chcon "$ctx" "$dir" 2>/dev/null
  find "$dir" -type f -exec chcon "$ctx" {} \; 2>/dev/null
  find "$dir" -type l -exec chcon -h "$ctx" {} \; 2>/dev/null
}

mount_effect_lib() {
  local target_dir="$1"
  local source_dir="$2"
  local work_dir="$MODDIR/work_mount$target_dir"

  [ -d "$target_dir" ] || return 0
  [ -f "$source_dir/libv4a_re.so" ] || return 0
  [ -f "$target_dir/libv4a_re.so" ] && return 0

  [ -d "$work_dir" ] && rm -rf "$work_dir"
  mkdir -p "$work_dir"
  cp -af "$target_dir"/* "$work_dir/" 2>/dev/null
  cp -f "$source_dir/libv4a_re.so" "$work_dir/libv4a_re.so"
  label_tree "$work_dir" u:object_r:vendor_file:s0
  ns_mount "$work_dir" "$target_dir"
  log "lib mount: $work_dir -> $target_dir"
}

mount_config() {
  local original="$1"
  local module_path="$2"
  local ctx

  [ -f "$original" ] || return 0
  [ -f "$module_path" ] || return 0
  cmp -s "$original" "$module_path" && return 0

  case "$original" in
  /system/*) ctx=u:object_r:system_file:s0 ;;
  *) ctx=u:object_r:vendor_configs_file:s0 ;;
  esac
  chcon "$ctx" "$module_path" 2>/dev/null

  ns_mount "$module_path" "$original"
  log "config mount: $module_path -> $original"
}

if [ "$SELF_MOUNT" = true ]; then
  # Mount here, before audioserver/audio HAL start; never restart audio at boot,
  # it makes system_server crash while initializing MiSound on BOOT_COMPLETED.
  for arch in lib lib64; do
    mount_effect_lib "/vendor/$arch/soundfx" "$MODDIR/system/vendor/$arch/soundfx"
    mount_effect_lib "/system/$arch/soundfx" "$MODDIR/system/$arch/soundfx"
  done

  for original in $(find /odm /system /vendor -type f \( -name 'audio_effects*.conf' -o -name 'audio_effects*.xml' \) 2>/dev/null); do
    case "$original" in
    /vendor/*) module_path="$MODDIR/system$original" ;;
    *) module_path="$MODDIR$original" ;;
    esac
    mount_config "$original" "$module_path"
  done

  log "lib present: $(ls /vendor/lib64/soundfx/libv4a_re.so 2>/dev/null || echo no)"
  log "odm qssi cfg v4a entries: $(grep -c v4a /odm/etc/audio/sku_pineapple_qssi/audio_effects.xml 2>/dev/null)"
fi

log "---> post-fs-data done <---"
