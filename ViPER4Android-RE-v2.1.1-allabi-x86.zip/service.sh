#!/system/bin/sh
MODDIR=${0%/*}

V4A_LOG=/data/adb/viper_install.log
log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] [service] $1" >>$V4A_LOG; }

log "---> service.sh start <---"

# Mounts are done in post-fs-data (before the audio HAL starts). Do NOT kill
# audioserver here: on this ROM that makes system_server crash while creating
# MiSound on BOOT_COMPLETED, which turns into a reboot loop.

i=0
while [ $i -lt 10 ]; do
  service list 2>/dev/null | grep -q 'viper.control' && break
  sleep 1
  i=$((i + 1))
done

if service list 2>/dev/null | grep -q 'viper.control'; then
  log "viper.control registered"
else
  log "WARNING: viper.control not registered"
fi

log "selinux: $(getenforce 2>/dev/null || echo unknown)"
log "lib present: $(ls /vendor/lib64/soundfx/libv4a_re.so 2>/dev/null || echo no)"
log "mounts: $(grep -c ViPER4Android /proc/1/mountinfo 2>/dev/null)"
log "--- service.sh done ---"
